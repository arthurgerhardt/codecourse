for i in 1...10 {
    print(i)
}

for j in 1..<10 {
    print(j)
}
