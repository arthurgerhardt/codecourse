var count = 1

while count <= 10 {
    print(count)
    count += 1
}

var count2 = 11

repeat {
    print(count2)
    count2 += 1
} while count2 <= 10
            
         
